﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _2._Point_in_Rectangle
{
    public class Point
    {
        public int X { get; set; }
        public int Y { get; set; }

        public Point(int x, int y)
        {
            X = x;
            Y = y;
        }
    }
}
