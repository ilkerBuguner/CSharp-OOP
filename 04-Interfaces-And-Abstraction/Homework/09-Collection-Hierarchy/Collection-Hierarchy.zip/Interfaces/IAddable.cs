﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Collection_Hierarchy.Interfaces
{
    public interface IAddable
    {
        int Add(string item); 
    }
}
