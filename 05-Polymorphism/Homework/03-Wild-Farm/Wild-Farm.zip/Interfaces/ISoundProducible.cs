﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wild_Farm.Interfaces
{
    public interface ISoundProducible
    {
        void ProduceSound();
    }
}
