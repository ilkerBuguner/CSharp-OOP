﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Logger.Enums
{
    public enum Level
    {
        INFO,
        WARNING,
        ERROR,
        CRITICAL,
        FATAL
    }
}
